﻿export default { reactStrictMode: true }

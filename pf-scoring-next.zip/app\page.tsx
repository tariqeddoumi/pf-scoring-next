﻿export default function Page(){
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-semibold">Bienvenue</h1>
      <p>Starter PF Scoring (Next.js + Supabase). Utilisez la navigation ci-dessus.</p>
    </div>
  )
}

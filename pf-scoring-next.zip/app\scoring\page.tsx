﻿export default function Scoring(){
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-semibold">Scoring (stub)</h1>
      <p>Connecter cette page aux tables `model_*` et `score_options` puis calculer la note et la PD.</p>
    </div>
  )
}
